//expresion ? ' si es true' : ''si es false'

let edad = 18;
let acceso = edad > 17 ? 'Permitir acceso' : 'No puede ingresar';
console.log (acceso);