let a = 5;
let b = 7;

console.log(a + b); //adición
console.log(a - b); //resta
console.log(a * b); //multiplicacion
console.log(a / b); //división
console.log(a % b); //resto de division
console.log(a ** b); //potencia

