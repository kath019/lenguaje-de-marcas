//AND, OR, NOT
//and
let mayor = false;
let suscrito = true;

console.log(true && true);
console.log(mayor && suscrito);

//or ||
console.log(mayor || suscrito);

//not
console.log(!mayor);