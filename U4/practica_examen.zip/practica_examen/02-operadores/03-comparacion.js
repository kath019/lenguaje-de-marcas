let a = 10;
console.log(a > 5);
console.log(a >= 5);
console.log(a < 5);
