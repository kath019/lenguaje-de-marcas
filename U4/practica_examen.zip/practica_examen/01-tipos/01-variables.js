let nombre ='Hola mundo';
let NombreCompleto;
let nombreCompleto;
let nombre_completo;
console.log(nombre);