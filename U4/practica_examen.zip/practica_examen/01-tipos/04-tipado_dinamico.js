let numero = 42;
let nombre = "Hola mundo";
let verdadero = true;
let undef;
let nulo = null;


console.log(typeof numero);
console.log(typeof nombre);
console.log(typeof verdadero);
console.log(typeof undef);
console.log(typeof nulo);