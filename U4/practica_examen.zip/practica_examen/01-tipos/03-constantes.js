const nombre = 'hola';
nombre = "Chancito feliz";/*me da error*/

console.log(nombre);

/*se usa 'const' la mayoría de las veces, porque es recomendable no modificar el contenido de la variable*/