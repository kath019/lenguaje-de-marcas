function suma (a, b) {
    console.log(arguments);
    return a + b;
}

//le pasamos un argumento
let resultado = suma(5, 6, 1, 2, 3);
console.log(resultado);
//o 
console.log(suma(5, 6));

//tipo de suma
console.log(typeof suma);
