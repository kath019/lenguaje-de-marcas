function saludar() {
    console.log('Hola mundo');
}

//llamar a la funcion
saludar();

//función con operación
function suma() {
    return 2+2;
}
//se crea una variable
let resultado = suma();

//se muestra la variable
console.log (resultado);
//o
console.log(suma());



