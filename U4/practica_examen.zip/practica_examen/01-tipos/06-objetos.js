//Personaje de TV
let nombre ="Tanijro";
let anime = "DEMON";
let edad = 16;


//esto es un objeto
let personaje = {
    nombre: "Tanjiro",
    anime: "DEMON",
    edad: 16
};

console.log(personaje);
console.log(personaje.edad);//linea 15 y 16 muestran lo mismo
console.log(personaje['edad']);

//si necesito modificar la propiedad
personaje.edad = 13;
personaje['edad'] = 17;
console.log (personaje.edad);


//para eliminar un atributo
delete personaje.anime;
console.log(personaje);