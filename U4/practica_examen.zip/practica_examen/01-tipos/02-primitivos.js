let numero = 1;
let texto = 'Chanchito feliz';
let verdadero = true;
let falso = false;
let noDefinido;
let nulo = null;/*se usa para el menú desplegable por ejemplo, cuando el usuario elige no escoger nada)*/