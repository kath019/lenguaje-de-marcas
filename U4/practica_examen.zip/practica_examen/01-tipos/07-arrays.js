//array con contenido inicial
let animales = ['chanchito', 'caballo'];
console.log(animales);

//para acceder a algun elemento del array
console.log(animales[0]);

//agregar elementos
animales[2] = 'dragón';
console.log(animales);

console.log (typeof animales);

console.log(animales.length);