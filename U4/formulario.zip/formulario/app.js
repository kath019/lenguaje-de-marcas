/* ===============================
   ACCESO AL DOM
================================ */

// Obtener referencias a elementos del HTML
const form = document.getElementById("mainForm"); //llamar elemento del html
const textInput = document.getElementById("textInput");
const colorSelect = document.getElementById("colorSelect");
const list = document.getElementById("itemList");
const counter = document.getElementById("counter");
const deleteMarkedBtn = document.getElementById("deleteMarked");
const selectedCounter = document.getElementById("selectedCounter");
const searchInput = document.getElementById("searchInput");
const actionSelect = document.getElementById("actionSelect");
//para 'id =' se usa getElem...
//para 'class = ' se usa ____querySelector(".______");


/* ===============================
   Funcion para marcar/desmarcar
================================ */
function applyAction() {
    const searchText = searchInput.value.toLowerCase().trim();
    const action = actionSelect.value;

    if (action === "") return;

    const items = list.querySelectorAll("li");

    items.forEach(item => {

        const itemText = item.textContent.toLowerCase();

        if (action === "mark") {

            // Si contiene el texto → marcar
            if (searchText !== "" && itemText.includes(searchText)) {
                item.classList.add("marked");
            } 
            // Si NO lo contiene → desmarcar
            else {
                item.classList.remove("marked");
            }
        }

        if (action === "unmark") {

            // Solo desmarca los que coinciden
            if (searchText !== "" && itemText.includes(searchText)) {
                item.classList.remove("marked");
            }
        }
    });

    // Actualiza el contador de seleccionados
    updateSelectedCounter();
}


/* ===============================
   EVENTO PARA MARCAR/DESMARCAR
================================ */
actionSelect.addEventListener("change", applyAction);



/* ===============================
   CONTADOR EN TIEMPO REAL
================================ */

// Evento input → se ejecuta cada vez que el usuario escribe
textInput.addEventListener("input", () => {
    counter.textContent = textInput.value.length;
});

//Evento que se ejecuta cada vez que el usuario selecciona algo
function updateSelectedCounter() {
    const markedItems = document.querySelectorAll(".marked");
    selectedCounter.textContent = markedItems.length;
}



/* ===============================
   EVENTO CHANGE
================================ */

// Cambia dinámicamente el color del input
colorSelect.addEventListener("change", () => {
    textInput.style.color = colorSelect.value || "black";
});

/* ===============================
   EVENTO SUBMIT
================================ */

// Evita que el formulario recargue la página
form.addEventListener("submit", (event) => {
    event.preventDefault();

    // Obtener texto ignorando mayúsculas/minúsculas
    const textValue = textInput.value.trim();

    if (textValue === "") return;

    // Crear nuevo nodo <li>
    const li = document.createElement("li");
    li.textContent = textValue;

    // Guardar el texto en minúsculas para comparaciones
    li.dataset.value = textValue.toLowerCase();

    // Evento click → marcar/desmarcar elemento
    li.addEventListener("click", () => {
        li.classList.toggle("marked");
        updateSelectedCounter(); // actualiza el contador al marcar/desmarcar
    });

    // Añadir el elemento a la lista
    list.appendChild(li);

    // Limpiar formulario
    form.reset();
    counter.textContent = "0";
    textInput.style.color = "black";
});

/* ===============================
   ELIMINAR ELEMENTOS MARCADOS
================================ */

deleteMarkedBtn.addEventListener("click", () => {

    // Obtener todos los elementos marcados
    const markedItems = document.querySelectorAll(".marked");

    // Eliminar cada nodo marcado del DOM
    markedItems.forEach(item => {
        item.remove();
    });
    updateSelectedCounter();

});







//ejercicio de STORE 
/* ==============================
   DATOS DE LOS PRODUCTOS

Array de objetos que representa los productos disponibles.
Estos datos se usarán para generar el HTML dinámicamente.*/
/*const PRODUCTOS = [
    {
        id: "ram-2x8gb", // Identificador único del producto
        title: "Memoria RAM Forgeon 2x8Gb", // Nombre del producto
        img: "assets/ram.webp", // Ruta de la imagen
        price: 80.67, // Precio
        bagde: "NUEVO" // Etiqueta visual (opcional)
    },
    {
        id: "QE65Q7FAAU",
        title: "Samsung Q7F QE65Q7FAAU",
        img: "assets/1151-samsung.webp",
        price: 519.00,
        bagde: null // Sin etiqueta
    },
    {
        id: "iphone-air-256",
        title: "Apple iPhone Air 256GB Negro Espacialb",
        img: "assets/apple-iphone-air.webp",
        price: 1099,
        bagde: "NUEVISIMO",
    },
]*/

/* ==============================
   CARRITO DE LA COMPRA
   ============================== */

/* Map para almacenar los productos del carrito.
 La clave es el id del producto y el valor es el producto con su cantidad.*/

/*    const cart = new Map()     */


/* ==============================
   AÑADIR PRODUCTOS AL CARRITO
   ============================== */

/*function addToCart(_id) {

    // Busca el producto en el array PRODUCTOS según su id
    const product = PRODUCTOS.find((p) => (p.id === _id))

    // Comprueba si el producto ya está en el carrito
    const existing = cart.get(_id)

    if (!existing) {
        // Si no existe, lo añade con cantidad 1
        cart.set(_id, { ...product, quantity: 1 })
    } else {
        // Si ya existe, aumenta la cantidad
        cart.set(_id, { ...existing, quantity: existing.quantity + 1 })
    }

    // Actualiza el HTML del carrito
    renderCart()
}*/

/* ==============================
   RENDERIZAR CARRITO EN EL HTML
   ============================== */

/*function renderCart() {

    // Obtiene los elementos del HTML donde se mostrará la info del carrito
    const spanElements = document.querySelector("#elements")
    const spanTotal = document.querySelector("#totalCart")

    let qtyTotal = 0 // Total de unidades
    let total = 0    // Precio total

    // Recorre todos los productos del carrito
    Array.from(cart.values()).forEach((_i) => {
        qtyTotal += _i.quantity
        total += _i.price * _i.quantity
    })

    // Actualiza el HTML con los valores calculados
    spanElements.innerHTML = qtyTotal + " unidades"
    spanTotal.innerHTML = total + " €"
}*/

/* ==============================
   RENDERIZAR PRODUCTOS EN EL HTML
   ============================== */

/*function renderProducts() {

    // Contenedor donde se insertarán los productos
    const productContainer = document.querySelector("#productos")
    if (!productContainer) return

    // Genera el HTML de cada producto
    const p = PRODUCTOS.map((p) => {

        // Si el producto tiene badge, se añade la etiqueta
        const badge = p.bagde
            ? `<span class="etiqueta">${p.bagde}</span>`
            : ""

        // Clase CSS diferente si el producto tiene etiqueta
        const classArticle = p.bagde ? "producto oferta" : "producto"

        // Devuelve el HTML del producto
        return `
        <article class="${classArticle}">
            ${badge}
            <img src="${p.img}" alt="${p.title}">
            <h3>${p.title}</h3>
            <p class="precio">${p.price} €</p>
            <a href="./detail.html" class="btn">Comprar</a>
            <button 
                data-add-to-cart="${p.id}" 
                type="button" 
                class="btn">
                Añadir al carrito
            </button>
        </article>
        `
    })

    // Inserta todos los productos en el HTML
    productContainer.innerHTML = p.join("")
}*/

/* ==============================
   EVENTO CLICK GLOBAL
   ============================== 
// Delegación de eventos: detecta clics en botones creados dinámicamente*/

/*document.addEventListener("click", (event) => {

    const target = event.target
    if (!(target instanceof HTMLElement)) return

    // Obtiene el id del producto desde el atributo data
    const pId = target.getAttribute("data-add-to-cart")

    // Si existe el atributo, se añade el producto al carrito
    if (pId) {
        addToCart(pId)
    }
})*/

/* ==============================
   EJECUCIÓN INICIAL
   ============================== 
 Genera los productos al cargar la página*/

 /*renderProducts()                su funcion es pintar los productos en el htaml*/
